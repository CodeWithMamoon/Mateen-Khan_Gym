import React from "react";

const Navbar = () => {
  return (
    <header>
      <p>ELITE EDGE FITNESS</p>
    </header>
  );
};

export default Navbar;
